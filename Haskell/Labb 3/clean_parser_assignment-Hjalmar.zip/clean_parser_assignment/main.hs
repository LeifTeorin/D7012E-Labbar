module Main where

import TestParser
import TestExpr
import TestStatement
import TestProgram

main :: IO ()
main = TestStatement.main